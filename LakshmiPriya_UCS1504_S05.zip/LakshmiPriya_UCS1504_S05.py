# -*- coding: utf-8 -*-
"""
Created on Mon Sep 21 13:24:03 2020

@author: Lakshmi Priya
"""

import random


def random_state(size): 
    return [random.randint(1, size) for i in range(size)]


def fitness(state):
    maxfitness = 28
    attacks = 0 
    n = len(state)
    
    for i in range(n):
        for j in range(i+1, n):
            #attack in coloumn
            if state[i] == state[j]:
                attacks += 1
            #attacks in diagonal 
            if state[i]+j-i == state[j] or state[i]+i-j == state[j]:
                attacks += 1
                
    return maxfitness - attacks


def probability(state):
    return fitness(state)/28


def random_state_select(population, prob_list):
    total_prob=0
    
    for prob in prob_list:
        total_prob += prob
        
    rand_prob = random.uniform(0, total_prob)
    
    limit = 0
    for i in range(len(population)):
        state = population[i]
        prob = prob_list[i]
        if limit + prob >= rand_prob:
            return state
        limit += prob
        

def reproduce(x, y): 
    n = len(x)
    c = random.randint(0, n-1)
    return x[0:c] + y[c:n]


def mutate(state): 
    n = len(state)
    index = random.randint(0, n-1)
    newval = random.randint(1, n)
    state[index] = newval
    return state


def next_genetic(population):
    mutation_prob = 0.05
    maxfitness = 28
    next_gen = []    
    prob_list = [probability(state) for state in population]

    for i in range(len(population)):
        state1 = random_state_select(population, prob_list) 
        state2 = random_state_select(population, prob_list) 

        child = reproduce(state1, state2) 

        if random.random() < mutation_prob: 
            child = mutate(child)

        next_gen.append(child)
        if fitness(child) == maxfitness: 
            break
    return next_gen


n = 8
maxfitness = 28
population = [random_state(n) for i in range(50)]

fitness_list=[]

while maxfitness not in fitness_list:
    population = next_genetic(population)
    fitness_list = [fitness(state) for state in population]

for state in population:
    if fitness(state) == maxfitness:
        print("Solution: ", state)
        
        for i in range(n):
            print(" X "*(state[i]-1)+" Q "+" X "*(n-state[i]))
            
'''

OUTPUT:
    
runfile('C:/Users/Lakshmi Priya/Documents/Python/nqueens_genetic.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Solution:  [3, 6, 2, 7, 1, 4, 8, 5]
 X  X  Q  X  X  X  X  X 
 X  X  X  X  X  Q  X  X 
 X  Q  X  X  X  X  X  X 
 X  X  X  X  X  X  Q  X 
 Q  X  X  X  X  X  X  X 
 X  X  X  Q  X  X  X  X 
 X  X  X  X  X  X  X  Q 
 X  X  X  X  Q  X  X  X 

runfile('C:/Users/Lakshmi Priya/Documents/Python/nqueens_genetic.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Solution:  [3, 7, 2, 8, 6, 4, 1, 5]
 X  X  Q  X  X  X  X  X 
 X  X  X  X  X  X  Q  X 
 X  Q  X  X  X  X  X  X 
 X  X  X  X  X  X  X  Q 
 X  X  X  X  X  Q  X  X 
 X  X  X  Q  X  X  X  X 
 Q  X  X  X  X  X  X  X 
 X  X  X  X  Q  X  X  X 
 
 runfile('C:/Users/Lakshmi Priya/Documents/Python/nqueens_genetic.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Solution:  [4, 2, 7, 3, 6, 8, 1, 5]
 X  X  X  Q  X  X  X  X 
 X  Q  X  X  X  X  X  X 
 X  X  X  X  X  X  Q  X 
 X  X  Q  X  X  X  X  X 
 X  X  X  X  X  Q  X  X 
 X  X  X  X  X  X  X  Q 
 Q  X  X  X  X  X  X  X 
 X  X  X  X  Q  X  X  X 
'''
 