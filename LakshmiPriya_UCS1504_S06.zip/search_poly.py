# -*- coding: utf-8 -*-
"""
Created on Mon Oct  5 12:52:39 2020

@author: Lakshmi Priya
"""

'''
(a) How do we formulate the state-space? How many states are there? How many paths are
there to the goal? Think carefully to define a good state-space. Justify your decisions.
Ans:     State space consists of vertices of polygon obstacles, starting point and ending point.
    In general, there are infinite number of states and paths to the goal state.

(b) How do we define the actions in your formulation of the state-space?
Ans:     Actions consist of travelling from one vertex to another vertex without colling with
    any obstacle. 

'''

import math
import copy
from collections import defaultdict 


class Node:
	def __init__(self, v1, v2):
		self.v1 = v1
		self.v2 = v2
        
	def __repr__(self):
		return str(self.v1)+" "+str(self.v2)
    
    
class Graph: 
    def __init__(self): 
        self.graph = defaultdict(list) 
  
    def addEdge(self,u,v): 
        self.graph[u].append(v) 
  
    def DFS(self, startpt, endpt): 
        path = []
        
        visited = defaultdict(list)
        for edge in self.graph:
            visited[edge] = False
            visited[tuple(self.graph[edge])] = False
            
        stack = [] 
        s = startpt
        stack.append(s) 
  
        path = [s]
        
        while stack: 
            s = stack.pop()
            
            if s==startpt:
                path = [s]
  
            for i in self.graph[s]: 
                if visited[i] == False: 
                    stack.append(i)
                    visited[i] = True
                    path.append(i)
                    if i==endpt:
                        break          

        return path
 
    def greedySearch(self, startpt, endpt): 
        path = []
        
        visited = defaultdict(list)
        for edge in self.graph:
            visited[edge] = False
            visited[tuple(self.graph[edge])] = False
            
        stack = [] 
        s = startpt
        stack.append(s) 
          
        path = [s]
        
        while stack: 
            s = stack.pop()
            
            if s==startpt:
                path = [s]
          
            for i in self.graph[s]: 
                mindist = math.inf
                minvertex = []
                if visited[i] == False: 
                    dist = (s[0]-i[0])**2 + (s[1]-i[1])**2
                    if dist < mindist:
                        mindist = dist
                        minvertex = i
                if minvertex != []:
                    stack.append(minvertex)
                    visited[minvertex] = True
                    path.append(minvertex)
                    if minvertex==endpt:
                        break      
        return path
    

class NodeState:
	def __init__(self, state, path, cost):
		self.state = state
		self.cost = cost
		self.path = path
        
        
def buildheap():                       #heap of Node(s)
	heap=[]
	heap.append(NodeState([], [], math.inf))   #sentinel for heap set
	return heap

def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	i=len(heap)-1
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].cost < heap[parent].cost):
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2

def deletemin(heap):                
	minval=heap[1]
	if(len(heap)==2):
	    return heap.pop()
	heap[1]=heap.pop()
	i=1
	while(2*i <= len(heap)-1):
		child=2*i
		if(child+1 < len(heap) and heap[child].cost > heap[child+1].cost):
			child += 1
		if(heap[i].cost > heap[child].cost):
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=child
	return minval


def heuristics(v1, v2):
    return (v1[0]-v2[0])**2 + (v1[1]-v2[1])**2

heap = buildheap()


def aStarSearch(nodes, currpt, cost, path, endpt): 
	vertex=currpt
	neighbours=nodes[tuple(currpt)]

	if vertex == endpt:
		return path
    
	for n in neighbours:
		nextvertex = n[0]
		nextcost = n[1]
		p=copy.deepcopy(path)
		p.append(nextvertex)
		insertheap(heap, NodeState(nextvertex, p, cost + nextcost + heuristics(vertex, nextvertex)))
        
	nextvertex = deletemin(heap)
	return aStarSearch(nodes, nextvertex.state, nextvertex.cost, nextvertex.path, endpt)


def connect(polygons, edges):
    n=len(polygons)
    
    for i in range(n-1):
        minm = math.inf
        minmvertex = []
        polygon1 = polygons[i]
        for p1 in polygon1:
            for j in range(i+1, n):
                polygon2 = polygons[j]
                for p2 in polygon2:
                    dist = (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2
                    if dist < minm:
                        minm = dist
                        minmvertex = [p1, p2]
        edges.append(Node(minmvertex[0], minmvertex[1]))


startpt = [0, 0]
endpt = [5, 5]

polygon1=[ [1, 1],
           [1, 2],
           [3, 1],
           [3, 2]
         ]

polygon2=[ [3, 3],
           [4, 5],
           [5, 3]
         ]

polygons=[[startpt],
          polygon1,
          polygon2,
          [endpt]
         ]


edges=[]
edges.append(Node([1,1], [1,2]))
edges.append(Node([1,1], [3,1]))
edges.append(Node([3,1], [3,2]))
edges.append(Node([1,2], [3,2]))
edges.append(Node([3,3], [4,5]))
edges.append(Node([3,3], [5,3]))
edges.append(Node([5,3], [4,5]))

connect(polygons, edges)

'''
for i in newedges:
    print(i)
'''

g = Graph() 

for edge in edges:
    g.addEdge(tuple(edge.v1), tuple(edge.v2))
    g.addEdge(tuple(edge.v2), tuple(edge.v1))
    
print("Edge list")
for edge in edges:
    print(edge)
    
    
path = g.DFS(tuple(startpt), tuple(endpt))

print("\nDFS")
for p in path:
    print(p)
    

path = g.greedySearch(tuple(startpt), tuple(endpt))

print("\nBest-first greedy search")
for p in path:
    print(p)


edgelist = []

for edge in edges:
    edgelist.append([edge.v1, edge.v2])
    
nodes = dict()

for edge in edgelist:
    if tuple(edge[0]) not in nodes:
        nodes[tuple(edge[0])] = [[edge[1], heuristics(edge[0], edge[1])]]
    else:
        nodes[tuple(edge[0])].append([edge[1], heuristics(edge[0], edge[1])])
        
nodes[tuple(endpt)] = []

'''
for i in nodes:
    print(i,nodes[i])
'''

path = aStarSearch(nodes, startpt, 0, [startpt], endpt)  

print("\nA* search")
for p in path:
    print(p)

'''
SOLUTION:
    
Edge list
[1, 1] [1, 2]
[1, 1] [3, 1]
[3, 1] [3, 2]
[1, 2] [3, 2]
[3, 3] [4, 5]
[3, 3] [5, 3]
[5, 3] [4, 5]
[0, 0] [1, 1]
[3, 2] [3, 3]
[4, 5] [5, 5]

DFS
(0, 0)
(3, 2)
(3, 3)
(4, 5)
(5, 3)
(5, 5)

Best-first greedy search
(0, 0)
(3, 2)
(3, 3)
(4, 5)
(5, 3)
(5, 5)

A* search
[0, 0]
[1, 1]
[1, 2]
[3, 2]
[3, 3]
[4, 5]
[5, 5]
'''