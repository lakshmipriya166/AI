# -*- coding: utf-8 -*-
"""
Created on Mon Aug 24 13:31:47 2020

@author: Lakshmi Priya
"""

"""
State Space Search—Decantation Problem

Problem formulation:
    State:  The state is a 3-tuple containing the amount 
            of water in 8-litre, 5-litre, 3-litre jar respectively 
    Initial state:  Any 3-tuple denoting amount of water in 
                    the respective jar
    Actions:  The 2 actions include: 
                Completely empty a jar into another jar with space
                Completely fill up a jar from another jar
    Transition model: Pouring from one jar to another jar
    Goal state:  Exactly 4 litres of water in one of the jars
    Path cost:  Number of states explored
"""

#(amt. in 8-litre jar, amt. in 5-litre jar, amt. in 3-litre jar)
 
def next_states(state, explored, parent):
    nextstates = []
    capacities = [8, 5, 3]
    
    for i in range(3):
        if state[i]>0:
            for j in range(3):
                if i!=j:
                    capacity = min(state[i], capacities[j]-state[j])
                    if capacity > 0:
                        new = list(state)
                        new[i] -= capacity
                        new[j] += capacity
                        new_state = tuple(new)
                    
                        if new_state not in explored:
                            parent[new_state]=state
                            nextstates.append(new_state)
                            if new_state[0] == 4 or new_state[1] == 4:
                                return nextstates

    return nextstates


def decantation(initial):

    if initial[0] == 4 or initial[1] == 4:
    	print('Given initial state is itself a final state')
    	return 

    explored = {}
    parent = {}
    queue = []
    queue.append(initial)
    
    count = 0
    
    print("\n\nExplored states: ")
    
    while len(queue):
    	state = queue.pop(0)
    	explored[state] = 1
    	count += 1
        
    	print(state)
        
    	nextstates = next_states(state, explored, parent)
        
    	if len(nextstates)>0 and (nextstates[-1][0] == 4 or nextstates[-1][1] == 4):
    		goalstate = nextstates[-1]
    		count += 1
    		print(nextstates[-1])
    		break
        
    	queue.extend(nextstates)
    
    print("Number of states explored = ", count)
    
    sequence = []
    
    currentstate=goalstate
    
    while(currentstate != initial):
    	sequence.append(currentstate)
    	currentstate = parent[currentstate]
        
    sequence.append(initial)
    
    print("\nSequence of states")
    for i in range(len(sequence)-1, -1, -1):
    	print(sequence[i])


print("Enter initial capacities separated by spaces: ")

initial = tuple(map(int, input().split()))
#print(initial)

decantation(initial)

"""

SAMPLE OUTPUT:

runfile('C:/Users/Lakshmi Priya/Documents/Python/decantation.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Enter initial capacities separated by spaces: 

8 0 0


Explored states: 
(8, 0, 0)
(3, 5, 0)
(5, 0, 3)
(0, 5, 3)
(3, 2, 3)
(0, 5, 3)
(5, 3, 0)
(6, 2, 0)
(2, 3, 3)
(6, 0, 2)
(2, 5, 1)
(1, 5, 2)
(1, 4, 3)
Number of states explored =  13

Sequence of states
(8, 0, 0)
(3, 5, 0)
(3, 2, 3)
(6, 2, 0)
(6, 0, 2)
(1, 5, 2)
(1, 4, 3)


runfile('C:/Users/Lakshmi Priya/Documents/Python/decantation.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Enter initial capacities separated by spaces: 

6 0 2


Explored states: 
(6, 0, 2)
(1, 5, 2)
(1, 4, 3)
Number of states explored =  3

Sequence of states
(6, 0, 2)
(1, 5, 2)
(1, 4, 3)


runfile('C:/Users/Lakshmi Priya/Documents/Python/decantation.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Enter initial capacities separated by spaces: 

4 1 1
Given initial state is itself a final state

"""      