# -*- coding: utf-8 -*-
"""
Created on Mon Sep 14 14:00:27 2020

@author: Lakshmi Priya
"""

#nqueens hill climbing

def numattacks(state):
    attacks = 0
    n=len(state)
    
    for i in range(n):
        for j in range(i+1, n):
            #attack in column
            if state[i] == state[j] :
                attacks += 1
                
            #attacks in diagonal
            if state[i]+i-j == state[j] or state[i]-i+j == state[j] :
                attacks += 1
                
    return attacks


def neighbours(state):
    minval=numattacks(state)
    best=state
    n=len(state)
    
    for i in range(n):
        for j in range(1,n):
            newstate = state[:]
            newstate[i] = newstate[i]+j
            
            if newstate[i] >= n:
                newstate[i] = newstate[i]%n
            
            cost=numattacks(newstate)
            
            if cost<minval:
                minval=cost
                best=newstate
                
    return best, minval


def nqueenshill(state):
    while True:
        if numattacks(state)==0:
            return state, 0
        
        best, minval = neighbours(state)
        
        if best == state:
            return best, minval
        
        state=best

    
state=[0,5,6,3,4,5,6,5]

print("Initial state: ",state)
print("Number of pairs of queens attacking each other directly/indirectly initially: ", numattacks(state))

fstate, attacks = nqueenshill(state)
print("\nFinal state: ", fstate)
print("Number of pairs of queens attacking each other directly/indirectly finally: ", attacks)

'''
OUTPUT:
    
runfile('C:/Users/Lakshmi Priya/Documents/Python/nqueenshill2.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Initial state:  [0, 5, 6, 3, 4, 5, 6, 5]
Number of pairs of queens attacking each other directly/indirectly initially:  18

Final state:  [2, 0, 6, 3, 7, 2, 7, 5]
Number of pairs of queens attacking each other directly/indirectly finally:  2

'''

        
    