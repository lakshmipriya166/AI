# -*- coding: utf-8 -*-
"""
Created on Mon Sep 14 13:14:23 2020

@author: Lakshmi Priya
"""

#centre point

def costfn(pts, centre):
    cost = 0
    for pt in pts:
        cost += abs(pt[0]-centre[0]) + abs(pt[1]-centre[1])
    return cost
    

def best_neighbour(pts, centre):
    neighbours=[[centre[0]+1, centre[1]], 
                [centre[0]-1, centre[1]],
                [centre[0], centre[1]+1],
                [centre[0], centre[1]-1]
               ]
    
    minval=costfn(pts, centre)
    best=centre
    
    cost=costfn(pts, neighbours[0])
    if cost < minval:
        minval=cost
        best=neighbours[0]
        
    cost=costfn(pts, neighbours[1])
    if cost < minval:
        minval=cost
        best=neighbours[1]
        
    cost=costfn(pts, neighbours[2])
    if cost < minval:
        minval=cost
        best=neighbours[2]
    
    cost=costfn(pts, neighbours[3])
    if cost < minval:
        minval=cost
        best=neighbours[3]
        
    return best, minval
    
    
def centre_hill_climbing(pts, centre):    
    while True:
        best, cost = best_neighbour(pts, centre)
        
        if best == centre:
            return best
        
        centre=best
        
    
pts=[[1,7],[2,3],[4,2],[7,1],[9,4]]
st=pts[0]
print("Centre point using hill climbing of ", pts, "is", centre_hill_climbing(pts,st))


'''
OUTPUT:
    
runfile('C:/Users/Lakshmi Priya/Documents/Python/centrept.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Centre point using hill climbing of  [[1, 7], [2, 3], [4, 2], [7, 1], [9, 4]] is [4, 3]

'''
