# -*- coding: utf-8 -*-
"""
Created on Mon Oct 19 12:56:46 2020

@author: Lakshmi Priya
"""

import math
from random import choice


human_win = -1
comp_win = +1

board = [
            [0, 0, 0],
            [0, 0, 0],
            [0, 0, 0]
        ]


def evaluate(state):
    """
    Function to heuristic evaluation of state.
    state -> the state of the current board
    returns +1 if the computer wins, -1 if the human wins or 0 if draw
    """
    if wins(state, comp_win):
        return 1
    elif wins(state, human_win):
        return -1
    return 0


def wins(state, player):
    """
    This function tests if a specific player wins. 
    Possibilities:
      Three row have same symbol in one column
      Three columns have same symbol in one row
      Diagonals have same symbol 
    state -> the state of the current board
    player -> human or computer
    returns True if the player wins else False
    """
    
    #different winning configurations
    win_config = [
        [state[0][0], state[0][1], state[0][2]],
        [state[1][0], state[1][1], state[1][2]],
        [state[2][0], state[2][1], state[2][2]],
        [state[0][0], state[1][0], state[2][0]],
        [state[0][1], state[1][1], state[2][1]],
        [state[0][2], state[1][2], state[2][2]],
        [state[0][0], state[1][1], state[2][2]],
        [state[2][0], state[1][1], state[0][2]]
    ]
    
    #winning configuration found in board, return True
    if [player, player, player] in win_config:
        return True
    else:
        return False


def game_over(state):
    """
    Tests the if the game is over
    state -> the state of the current board
    returns True if the human or computer wins
    """
    return wins(state, human_win) or wins(state, comp_win)


def empty_cells(state):
    """
    Each empty cell will be added into empty list
    state -> the state of the current board
    returns a list of empty cells
    """
    empty = []

    for x in range(len(state)):
        for y in range(len(state[0])):
            if state[x][y] == 0:
                empty.append([x, y])

    return empty


def valid_move(x, y):
    """
    A move is valid if the chosen cell is empty
    x -> x coordinate
    y -> y coordinate
    returns True if the board[x][y] is empty
    """
    if [x, y] in empty_cells(board):
        return True
    else:
        return False


def set_move(x, y, player):
    """
    Set the move on board, if the coordinates are valid
    x -> x coordinate
    y -> y coordinate
    player -> the current player
    """
    if valid_move(x, y):
        board[x][y] = player
        return True
    else:
        return False


def minimax(state, depth, player):
    """
    Function chooses the best move
    state -> current state of the board
    depth -> node index in the tree (0 <= depth < 9)
    player -> human or computer
    returns list with [best row, best col, best score]
    """
    if player == comp_win:
        best = [-1, -1, -math.inf]
    else:
        best = [-1, -1, math.inf]

    if depth == 0 or game_over(state):
        score = evaluate(state)
        return [-1, -1, score]

    for cell in empty_cells(state):
        x, y = cell[0], cell[1]
        state[x][y] = player
        score = minimax(state, depth - 1, -player)
        state[x][y] = 0
        score[0] = x
        score[1] = y

        if player == comp_win:
            if score[2] > best[2]:
                best = score  # max value
        else:
            if score[2] < best[2]:
                best = score  # min value

    return best


def print_board(state, comp_choice, human_choice):
    """
    Print the board
    state -> current state of the board
    """

    chars = {
        -1: human_choice,
        +1: comp_choice,
        0: ' '
    }

    print('\n---------------')
    for row in state:
        for cell in row:
            symbol = chars[cell]
            print('|',symbol,'|', end='')
        print('\n---------------')


def comp_play(comp_choice, human_choice):
    """
    Function calls the minimax function if the depth < 9,
    else it choices a random coordinate.
    comp_choice: computer's choice X or O
    human_choice: human's choice X or O
    """
    depth = len(empty_cells(board))
    if depth == 0 or game_over(board):
        return
    
    if depth == 9:
        x = choice([0, 1, 2])
        y = choice([0, 1, 2])
    else:
        move = minimax(board, depth, comp_win)
        x, y = move[0], move[1]

    print('My turn', comp_choice)
    set_move(x, y, comp_win)

    print_board(board, comp_choice, human_choice)


def human_play(comp_choice, human_choice):
    """
    Human move
    comp_choice: computer's choice X or O
    human_choice: human's choice X or O
    """
    depth = len(empty_cells(board))
    if depth == 0 or game_over(board):
        return

    # Valid moves
    move = -1
    moves = {
        1: [0, 0], 2: [0, 1], 3: [0, 2],
        4: [1, 0], 5: [1, 1], 6: [1, 2],
        7: [2, 0], 8: [2, 1], 9: [2, 2],
    }

    print_board(board, comp_choice, human_choice)
    
    while move < 1 or move > 9:
        print('Your turn', human_choice)
        move = int(input('Enter position (1 to 9): '))
        
        x, y = moves[move]
        can_move = set_move(x, y, human_win)

        if not can_move:
            print('Invalid move')
            move = -1


human_choice = ''  # X or O
comp_choice = ''  # X or O
first = ''  # if human is the first

# Human chooses X or O to play
while human_choice != 'O' and human_choice != 'X':
    human_choice = input('Choose X or O: ').upper()
    if human_choice != 'O' and human_choice != 'X':
        print('Invalid choice')

# Setting computer's choice
if human_choice == 'X':
    comp_choice = 'O'
else:
    comp_choice = 'X'

# Deciding first player
while first != 'Y' and first != 'N':
    first = input('Want to start first? [y/n]: ').upper()
    if first != 'Y' and first != 'N':
        print('Invalid choice')
        
# Game playing
while len(empty_cells(board)) > 0 and not game_over(board):
    if first == 'N':
        comp_play(comp_choice, human_choice)
        first = ''

    human_play(comp_choice, human_choice)
    comp_play(comp_choice, human_choice)

# Game result
if wins(board, human_win):
    print_board(board, comp_choice, human_choice)
    print('YOU WIN!')
elif wins(board, comp_win):
    print_board(board, comp_choice, human_choice)
    print('YOU LOSE!')
else:
    print_board(board, comp_choice, human_choice)
    print('DRAW!')


'''
runfile('C:/Users/Lakshmi Priya/Documents/Python/minimaxXO.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')

Choose X or O: X

Want to start first? [y/n]: Y

---------------
|   ||   ||   |
---------------
|   ||   ||   |
---------------
|   ||   ||   |
---------------
Your turn X

Enter position (1 to 9): 4
My turn O

---------------
| O ||   ||   |
---------------
| X ||   ||   |
---------------
|   ||   ||   |
---------------

---------------
| O ||   ||   |
---------------
| X ||   ||   |
---------------
|   ||   ||   |
---------------
Your turn X

Enter position (1 to 9): 4
Invalid move
Your turn X

Enter position (1 to 9): 6
My turn O

---------------
| O ||   ||   |
---------------
| X || O || X |
---------------
|   ||   ||   |
---------------

---------------
| O ||   ||   |
---------------
| X || O || X |
---------------
|   ||   ||   |
---------------
Your turn X

Enter position (1 to 9): 9
My turn O

---------------
| O ||   || O |
---------------
| X || O || X |
---------------
|   ||   || X |
---------------

---------------
| O ||   || O |
---------------
| X || O || X |
---------------
|   ||   || X |
---------------
Your turn X

Enter position (1 to 9): 2
My turn O

---------------
| O || X || O |
---------------
| X || O || X |
---------------
| O ||   || X |
---------------

---------------
| O || X || O |
---------------
| X || O || X |
---------------
| O ||   || X |
---------------
YOU LOSE!



runfile('C:/Users/Lakshmi Priya/Documents/Python/minimaxXO.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')

Choose X or O: N
Invalid choice

Choose X or O: X

Want to start first? [y/n]: Y

---------------
|   ||   ||   |
---------------
|   ||   ||   |
---------------
|   ||   ||   |
---------------
Your turn X

Enter position (1 to 9): 5
My turn O

---------------
| O ||   ||   |
---------------
|   || X ||   |
---------------
|   ||   ||   |
---------------

---------------
| O ||   ||   |
---------------
|   || X ||   |
---------------
|   ||   ||   |
---------------
Your turn X

Enter position (1 to 9): 3
My turn O

---------------
| O ||   || X |
---------------
|   || X ||   |
---------------
| O ||   ||   |
---------------

---------------
| O ||   || X |
---------------
|   || X ||   |
---------------
| O ||   ||   |
---------------
Your turn X

Enter position (1 to 9): 4
My turn O

---------------
| O ||   || X |
---------------
| X || X || O |
---------------
| O ||   ||   |
---------------

---------------
| O ||   || X |
---------------
| X || X || O |
---------------
| O ||   ||   |
---------------
Your turn X

Enter position (1 to 9): 2
My turn O

---------------
| O || X || X |
---------------
| X || X || O |
---------------
| O || O ||   |
---------------

---------------
| O || X || X |
---------------
| X || X || O |
---------------
| O || O ||   |
---------------
Your turn X

Enter position (1 to 9): 9

---------------
| O || X || X |
---------------
| X || X || O |
---------------
| O || O || X |
---------------
DRAW!
'''