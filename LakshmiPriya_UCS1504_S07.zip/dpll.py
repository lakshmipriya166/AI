# -*- coding: utf-8 -*-
'''
Created on Mon Oct 12 13:10:43 2020

@author: Lakshmi Priya
'''

# DPLL-Satisfiable

from copy import deepcopy


def prop_symbols(s):
    return [i for i in list(set(s)) if i.isalpha()]
    

def conjuncts(s):
    return [i for i in s.splitlines() if i!='']

    
def print_cnf(cnf):
    s = ''
    for i in cnf:
        if len(i) > 0:
            s += '(' + i.replace(' ', '+') + ')'
    if s == '':
        s = '()'
    print(s)

    
def dpll_satisfiable(s):
    model = [set(), set()]
    if dpll(conjuncts(s), prop_symbols(s), model):
        print('\nResult: SATISFIABLE')
        print('Assignment:')
        trueSymbols = model[0]
        falseSymbols = model[1]
        for i in trueSymbols:
            print('\t'+i, '= True')
        for i in falseSymbols:
            print('\t'+i, '= False')
    else:
        #print('\nReached starting node!')
        print('\nResult: UNSATISFIABLE')


def dpll(cnf, literals, model):
    '''See if the clauses are true in a partial model.'''
    
    print('\nCNF : ', end='')
    print_cnf(cnf)
    
    cnf = list(set(cnf))
    
    if find_pure_symbol(cnf, literals, model):
        return True
    
    new_true, new_false = find_unit_clause(cnf, model)
      
    if len(cnf) == 0:
        return True

    if sum(len(clause)==0 for clause in cnf):
        for i in new_true:
            model[0].remove(i)
        for i in new_false:
            model[1].remove(i)
        print('Backtracking from NULL clause')
        return False
    
    print_cnf(cnf)
    literals = [k for k in list(set(''.join(cnf))) if k.isalpha()]

    x = literals[0]
    if dpll(deepcopy(cnf)+[x], deepcopy(literals), model):
        return True
    elif dpll(deepcopy(cnf)+['~'+x], deepcopy(literals), model):
        return True
    else:
        for i in new_true:
            model[0].remove(i)
        for i in new_false:
            model[1].remove(i)
        return False
    

def find_pure_symbol(cnf, literals, model):
    '''Find a symbol and its value if it appears only as a positive literal
    (or only as a negative) in clauses.
    '''
    for l in literals:
        for c in cnf:
            c = c.replace('~'+l, '$')
            if l not in c:
                break
        else:
            model[0].add(l)
            return True
        
        for c in cnf:
            c = c.replace('~'+l, '$')
            if l.count('$')==0:
                break
        else:
            model[1].add(l)
            return True
        
    return False


def find_unit_clause(cnf, model):
    '''Find a forced assignment if possible from a clause with only 1
    variable not bound in the model.
    '''
    new_true = []
    new_false = []
    
    units = [i for i in cnf if len(i)<3]
    units = list(set(units))
    if len(units):
        for unit in units:
            unit_clause_assign(unit, cnf, model, new_true, new_false)
    print('Units =', units)
    print('CNF after unit propogation = ', end = '')
    print_cnf(cnf)
    return new_true, new_false
    

def unit_clause_assign(unit, cnf, model, new_true, new_false):
    '''Return a single variable/value pair that makes clause true in
    the model, if possible.
    '''
    
    if '~' in unit:
        model[1].add(unit[-1])
        new_false.append(unit[-1])
        i = 0
        while True:
            if unit in cnf[i]:
                cnf.remove(cnf[i])
                i -= 1
            elif unit[-1] in cnf[i]:
                cnf[i] = cnf[i].replace(unit[-1], '').strip()
            i += 1
            if i >= len(cnf):
                break
    else:
        model[0].add(unit)
        new_true.append(unit)
        i = 0
        while True:
            if '~'+unit in cnf[i]:
                cnf[i] = cnf[i].replace('~'+unit, '').strip()
                if '  ' in cnf[i]:
                    cnf[i] = cnf[i].replace('  ', ' ')
            elif unit in cnf[i]:
                cnf.remove(cnf[i])
                i -= 1
            i += 1
            if i >= len(cnf):
                break
        

print('\nEnter clauses in each line\nUse ~ to denote negation')
print('Example:\n~B ~C A\n~C ~A ~B\nB A ~C\nB\n')
print('\nClause')
input_cnf = ''
while True:
    clause = input()
    if len(clause)==0:
        break
    input_cnf = input_cnf + '\n' + clause

dpll_satisfiable(input_cnf)


'''
Output:

runfile('C:/Users/Lakshmi Priya/Documents/Python/dpll1.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')

Enter clauses in each line
Use ~ to denote negation
Example:
~B ~C A
~C ~A ~B
B A ~C
B


Clause

A B ~C

~A ~B ~C

A B C



CNF : (A+B+~C)(~A+~B+~C)(A+B+C)
Units = []
CNF after unit propogation = (~A+~B+~C)(A+B+C)(A+B+~C)
(~A+~B+~C)(A+B+C)(A+B+~C)

CNF : (~A+~B+~C)(A+B+C)(A+B+~C)(C)
Units = ['C']
CNF after unit propogation = (A+B)(~A+~B)
(A+B)(~A+~B)

CNF : (A+B)(~A+~B)(B)
Units = ['B']
CNF after unit propogation = (~A)
(~A)

CNF : (~A)(A)
Units = ['~A', 'A']
CNF after unit propogation = ()
Backtracking from NULL clause

CNF : (~A)(~A)
Units = ['~A']
CNF after unit propogation = ()

Result: SATISFIABLE
Assignment:
        B = True
        C = True
        A = False

runfile('C:/Users/Lakshmi Priya/Documents/Python/dpll1.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')

Enter clauses in each line
Use ~ to denote negation
Example:
~B ~C A
~C ~A ~B
B A ~C
B


Clause

A B C

A ~B C

A B ~C

A B C D



CNF : (A+B+C)(A+~B+C)(A+B+~C)(A+B+C+D)

Result: SATISFIABLE
Assignment:
        A = True

'''