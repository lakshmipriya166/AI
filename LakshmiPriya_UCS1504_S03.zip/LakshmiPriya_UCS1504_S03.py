# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 12:56:55 2020

@author: Lakshmi Priya
"""

import math
import copy

class Node:
	def __init__(self, state, cost, space_row, space_col):
		self.state = state
		self.cost = cost
		self.space_row = space_row
		self.space_col = space_col

	def __repr__(self):
		return str((self.state, self.cost))

book=dict()
book2=dict()
book3=dict()


def hashfn(puzzle):
	key=[puzzle[i][j] for i in range(len(puzzle)) for j in range(len(puzzle[0]))]
	return tuple(key)


def buildheap():                       #heap of Node(s)
	heap=[]
	heap.append(Node([], -math.inf, 0, 0))   #sentinel for heap set
	return heap

def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	i=len(heap)-1
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].cost < heap[parent].cost):
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2

def deletemin(heap):                
	minval=heap[1]
	if(len(heap)==2):
	    return heap.pop()
	heap[1]=heap.pop()
	i=1
	while(2*i <= len(heap)-1):
		child=2*i
		if(child+1 < len(heap) and heap[child].cost > heap[child+1].cost):
			child += 1
		if(heap[i].cost > heap[child].cost):
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=child
	return minval


goalstate=[ [0,0], [0,1], [0,2], 
			[1,0], [1,1], [1,2], 
			[2,0], [2,1], [2,2]
		  ]


#Uninformed Search Strategy - PRIORITY FIRST SEARCH

def npuzzle_pfs(node):
	puzzle=node.state
	cost=node.cost
	x=node.space_row
	y=node.space_col

	n=len(puzzle)
	if(heuristics(puzzle)==0):
		return
	puzzlehash=hashfn(puzzle)
	if(x>0):   #slide space UP
		p=copy.deepcopy(puzzle)
		p[x][y], p[x-1][y] = p[x-1][y], p[x][y]
		if hashfn(p) not in book3:
			book3[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, cost+1, x-1, y))
	if(x<n-1):   #slide space DOWN
		p=copy.deepcopy(puzzle)
		p[x][y], p[x+1][y] = p[x+1][y], p[x][y]
		if hashfn(p) not in book3:
			book3[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, cost+1, x+1, y))
	if(y>0):   #slide space LEFT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y-1] = p[x][y-1], p[x][y]
		if hashfn(p) not in book3:
			book3[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, cost+1, x, y-1))
	if(y<n-1):   #slide space RIGHT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y+1] = p[x][y+1], p[x][y]
		if hashfn(p) not in book3:
			book3[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, cost+1, x, y+1))
	nextnode=deletemin(heap)
	npuzzle_pfs(nextnode)
    

#Informed Search Strategy - GREEDY BEST FIRST SEARCH
def heuristics(puzzle):
	h=0
	for i in range(len(puzzle)):
		for j in range(len(puzzle[0])):
			if(puzzle[i][j]!=-1):
				h+=abs(i-goalstate[puzzle[i][j]][0])+abs(j-goalstate[puzzle[i][j]][1])
	return h

def npuzzle_gbfs(node):
	visited=dict()
	puzzle=node.state
	x=node.space_row
	y=node.space_col

	n=len(puzzle)
	if(heuristics(puzzle)==0):
		return
	puzzlehash=hashfn(puzzle)
	if(x>0):   #slide space UP
		p=copy.deepcopy(puzzle)
		p[x][y], p[x-1][y] = p[x-1][y], p[x][y]
		if(hashfn(p) not in visited and heuristics(puzzle)>heuristics(p)):
			book[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, heuristics(p), x-1, y))
			visited[hashfn(p)]=1
	if(x<n-1):   #slide space DOWN
		p=copy.deepcopy(puzzle)
		p[x][y], p[x+1][y] = p[x+1][y], p[x][y]
		if(hashfn(p) not in visited and heuristics(puzzle)>heuristics(p)):
			book[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, heuristics(p), x+1, y))
			visited[hashfn(p)]=1
	if(y>0):   #slide space LEFT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y-1] = p[x][y-1], p[x][y]
		if(hashfn(p) not in visited and heuristics(puzzle)>heuristics(p)):
			book[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, heuristics(p), x, y-1))
			visited[hashfn(p)]=1
	if(y<n-1):   #slide space RIGHT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y+1] = p[x][y+1], p[x][y]
		if(hashfn(p) not in visited and heuristics(puzzle)>heuristics(p)):
			book[hashfn(p)]=puzzlehash
			insertheap(heap, Node(p, heuristics(p), x, y+1))
			visited[hashfn(p)]=1
	nextnode=deletemin(heap)
	npuzzle_gbfs(nextnode)

	
def heuristics2(puzzle, cost):
	h=cost
	for i in range(len(puzzle)):
		for j in range(len(puzzle[0])):
			if(puzzle[i][j]!=-1):
				h+=abs(i-goalstate[puzzle[i][j]][0])+abs(j-goalstate[puzzle[i][j]][1])
	return h


#Informed Search Strategy - A* SEARCH
def npuzzle_astar(node):
	puzzle=node.state
	cost=node.cost
	x=node.space_row
	y=node.space_col

	n=len(puzzle)
	if(heuristics(puzzle)==0):
		return
	puzzlehash=hashfn(puzzle)
	if(x>0):   #slide space UP
		p=copy.deepcopy(puzzle)
		p[x][y], p[x-1][y] = p[x-1][y], p[x][y]
		if(heuristics2(puzzle, cost)>heuristics2(p, cost)):
			book2[hashfn(p)]=puzzlehash
		insertheap(heap, Node(p, heuristics2(p, cost), x-1, y))
	if(x<n-1):   #slide space DOWN
		p=copy.deepcopy(puzzle)
		p[x][y], p[x+1][y] = p[x+1][y], p[x][y]
		if(heuristics2(puzzle, cost)>heuristics2(p, cost)):
			book2[hashfn(p)]=puzzlehash
		insertheap(heap, Node(p, heuristics2(p, cost), x+1, y))
	if(y>0):   #slide space LEFT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y-1] = p[x][y-1], p[x][y]
		if(heuristics2(puzzle, cost)>heuristics2(p, cost)):
			book2[hashfn(p)]=puzzlehash
		insertheap(heap, Node(p, heuristics2(p, cost), x, y-1))
	if(y<n-1):   #slide space RIGHT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y+1] = p[x][y+1], p[x][y]
		if(heuristics2(puzzle, cost)>heuristics2(p, cost)):
			book2[hashfn(p)]=puzzlehash
		insertheap(heap, Node(p, heuristics2(p, cost), x, y+1))
	nextnode=deletemin(heap)
	npuzzle_astar(nextnode)


puzzle=[[0, 4, 1],
		[-1, 7, 2],
		[3, 6, 5]
	   ]
spaceindex=[1,0]


#----------PFS
heap=buildheap()
print("\n\n********************************************")
print("n puzzle using PFS:")
print("Evaluation function f(s) = g(s)")
print("********************************************")
npuzzle_pfs(Node(puzzle, 0, spaceindex[0], spaceindex[1]))

res=(0,1,2,3,4,5,6,7,-1)
    
order=[]
order.append(res)

while(res!=hashfn(puzzle)):
	res=book3[res]
	order.append(res)

n=len(puzzle)

for i in range(len(order)-1, -1, -1):
    print(str(order[i][0:n])+"\n"+str(order[i][n:2*n])+"\n"+str(order[i][2*n:3*n]))
    if(i!=0):
        print("    |")
        print("    V")

#----------GBFS
heap=buildheap()
print("\n\n********************************************")
print("n puzzle using Greedy BFS:")
print("Evaluation function f(s) = h(s)")
print("********************************************")
npuzzle_gbfs(Node(puzzle, heuristics(puzzle), spaceindex[0], spaceindex[1]))
    
res=(0,1,2,3,4,5,6,7,-1)
    
order=[]
order.append(res)

while(res!=hashfn(puzzle)):
	res=book[res]
	order.append(res)

n=len(puzzle)

for i in range(len(order)-1, -1, -1):
    print(str(order[i][0:n])+"\n"+str(order[i][n:2*n])+"\n"+str(order[i][2*n:3*n]))
    if(i!=0):
        print("    |")
        print("    V")
    
    
#----------A*
heap=buildheap()
print("\n\n********************************************")
print("n puzzle using A*")
print("Evaluation function f(s) = g(s) + h(s)")
print("********************************************")
npuzzle_astar(Node(puzzle, heuristics2(puzzle, 0), spaceindex[0], spaceindex[1]))

res=(0,1,2,3,4,5,6,7,-1)

order=[]
order.append(res)
    
while(res!=hashfn(puzzle)):
	res=book2[res]
	order.append(res)

n=len(puzzle)

for i in range(len(order)-1, -1, -1):
    print(str(order[i][0:n])+"\n"+str(order[i][n:2*n])+"\n"+str(order[i][2*n:3*n]))
    if(i!=0):
        print("    |")
        print("    V")

'''
SOLUTION


runfile('C:/Users/Lakshmi Priya/Documents/Python/npuzzle5.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')


********************************************
n puzzle using PFS:
Evaluation function f(s) = g(s)
********************************************
(0, 4, 1)
(-1, 7, 2)
(3, 6, 5)
    |
    V
(0, 4, 1)
(3, 7, 2)
(-1, 6, 5)
    |
    V
(0, 4, 1)
(3, 7, 2)
(6, -1, 5)
    |
    V
(0, 4, 1)
(3, -1, 2)
(6, 7, 5)
    |
    V
(0, -1, 1)
(3, 4, 2)
(6, 7, 5)
    |
    V
(0, 1, -1)
(3, 4, 2)
(6, 7, 5)
    |
    V
(0, 1, 2)
(3, 4, -1)
(6, 7, 5)
    |
    V
(0, 1, 2)
(3, 4, 5)
(6, 7, -1)


********************************************
n puzzle using Greedy BFS:
Evaluation function f(s) = h(s)
********************************************
(0, 4, 1)
(-1, 7, 2)
(3, 6, 5)
    |
    V
(0, 4, 1)
(3, 7, 2)
(-1, 6, 5)
    |
    V
(0, 4, 1)
(3, 7, 2)
(6, -1, 5)
    |
    V
(0, 4, 1)
(3, -1, 2)
(6, 7, 5)
    |
    V
(0, -1, 1)
(3, 4, 2)
(6, 7, 5)
    |
    V
(0, 1, -1)
(3, 4, 2)
(6, 7, 5)
    |
    V
(0, 1, 2)
(3, 4, -1)
(6, 7, 5)
    |
    V
(0, 1, 2)
(3, 4, 5)
(6, 7, -1)


********************************************
n puzzle using A*
Evaluation function f(s) = g(s) + h(s)
********************************************
(0, 4, 1)
(-1, 7, 2)
(3, 6, 5)
    |
    V
(0, 4, 1)
(3, 7, 2)
(-1, 6, 5)
    |
    V
(0, 4, 1)
(3, 7, 2)
(6, -1, 5)
    |
    V
(0, 4, 1)
(3, -1, 2)
(6, 7, 5)
    |
    V
(0, -1, 1)
(3, 4, 2)
(6, 7, 5)
    |
    V
(0, 1, -1)
(3, 4, 2)
(6, 7, 5)
    |
    V
(0, 1, 2)
(3, 4, -1)
(6, 7, 5)
    |
    V
(0, 1, 2)
(3, 4, 5)
(6, 7, -1)
'''
