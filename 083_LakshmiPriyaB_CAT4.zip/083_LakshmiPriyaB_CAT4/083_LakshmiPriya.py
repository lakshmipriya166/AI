####################################
#NAME             : LAKSHMI PRIYA B
#REGISTER NUMBER  : 185001083
####################################

# -*- coding: utf-8 -*-
"""
Created on Sat Nov  7 09:54:23 2020

@author: Lakshmi Priya
"""

import math

class Node:
	def __init__(self, state, cost, prevcost):
		self.state = state
		self.cost = cost
		self.prevcost = prevcost
        
	def __repr__(self):
		return str((self.state, self.cost))

book=dict()
book2=dict()


def buildheap():                       #heap of Node(s)
	heap=[]
	heap.append(Node([], math.inf, 0))   #sentinel for heap set
	return heap

def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	i=len(heap)-1
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].cost < heap[parent].cost):
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2

def deletemin(heap):                
	minval=heap[1]
	if(len(heap)==2):
	    return heap.pop()
	heap[1]=heap.pop()
	i=1
	while(2*i <= len(heap)-1):
		child=2*i
		if(child+1 < len(heap) and heap[child].cost > heap[child+1].cost):
			child += 1
		if(heap[i].cost > heap[child].cost):
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=child
	return minval


#Informed Search Strategy - BEST FIRST SEARCH
def heuristics(state):
	h=0
	for i in range(len(state)):
		h+=abs(state[i]-i-1)
	return h


print('Heuristic function check: heuristics([1,3,2,5,4]): ', heuristics([1,3,2,5,4]))
    

def bestFirstSearch(node):
	visited=dict()
	state=node.state
    
	visited[state]=1

	n=len(state)
    
	statecost=heuristics(state)
    
	if statecost==0:
		return
    
	for i in range(n):
		for j in range(i, n):
			newstate = state[:i]+state[j+1:]+state[i:j+1]
			#print(newstate)
			newstatecost = heuristics(newstate)
            
			if newstate not in visited and statecost > newstatecost:
				book[newstate]=state
				insertheap(heap, Node(newstate, newstatecost, 0))
				visited[newstate]=1
                
	nextnode=deletemin(heap)
	bestFirstSearch(nextnode)
            

def heuristics2(state):
	for i in range(len(state)):
		if state[i]-1 != i:
			return 1
	return 0


print('Heuristic function 2 check: heuristics([1,3,2,5,4])', heuristics([1,3,2,5,4]))

#Informed Search Strategy - A* SEARCH
def astar(node):
    
	state = node.state
	n=len(state)
    
	statecost=heuristics(state)
    
	if statecost==0:
		return
    
	for i in range(n):
		for j in range(i, n):
			newlist = state[:i]+state[j+1:]
			for k in range(len(newlist)):
				newstate = newlist[:k]+state[i:j+1]+newlist[k:]
				#print(newstate)
				newstatecost = heuristics2(newstate)
            
				if newstate not in book2:
					book2[newstate]=state
					insertheap(heap, Node(newstate, newstatecost+node.prevcost, node.prevcost+1))
                
	nextnode=deletemin(heap)
    
	astar(nextnode)
        
    
#----------BFS

heap=buildheap()
print("\n\n********************************************")
print("Sorting using Best First Search:")
print("Evaluation function f(s) = h(s)")
print("********************************************")
state = (5,4,3,2,1)
start = Node(state, 0, 0) 
n = len(state)

print('Insertheap function tested\n')
insertheap(heap, start)

bestFirstSearch(start)

res=[i for i in range(1, n+1)]
res=tuple(res)
    
order=[]
order.append(res)

count=0
while(res!=state):
	res=book[res]
	order.append(res)
	count+=1
    

for i in range(len(order)-1, -1, -1):
    print(order[i])

print('Moves for Best First Serch is ', count)   
    
    
#----------A*
heap=buildheap()
print("\n\n********************************************")
print("Sorting using A*")
print("Evaluation function f(s) = g(s) + h(s)")
print("********************************************")
state = (5,4,3,2,1)
start = Node(state, 0, 0) 
n = len(state)

print('Insertheap function tested\n')
insertheap(heap, start)

astar(start)

res=[i for i in range(1, n+1)]
res=tuple(res)
    
order=[]
order.append(res)

count=0
while(res!=state):
	res=book2[res]
	order.append(res)
	count+=1
    
for i in range(len(order)-1, -1, -1):
	print(order[i])
    
print('Moves for A* Search is ', count)
    

'''
SOLUTION:
runfile('C:/Users/Lakshmi Priya/Documents/Python/083_LakshmiPriya.py', wdir='C:/Users/Lakshmi Priya/Documents/Python')
Heuristic function check: heuristics([1,3,2,5,4]):  4
Heuristic function 2 check: heuristics([1,3,2,5,4]) 4


********************************************
Sorting using Best First Search:
Evaluation function f(s) = h(s)
********************************************
Insertheap function tested

(5, 4, 3, 2, 1)
(1, 5, 4, 3, 2)
(1, 2, 5, 4, 3)
(1, 2, 3, 5, 4)
(1, 2, 3, 4, 5)
Moves for Best First Serch is  4


********************************************
Sorting using A*
Evaluation function f(s) = g(s) + h(s)
********************************************
Insertheap function tested

(5, 4, 3, 2, 1)
(5, 2, 1, 4, 3)
(1, 4, 5, 2, 3)
(1, 2, 3, 4, 5)
Moves for A* Search is  3
'''